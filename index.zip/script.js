//OPERADORES ARITMÉTICOS

function somar() {
    let num1 = parseFloat(document.getElementById('num1').value);
    let num2 = parseFloat(document.getElementById('num2').value);
    let resultado = num1 + num2;
    document.getElementById('resultadoAritmetico').innerText = 'RESULTADO: ' + resultado;
}

function subtrair() {
    let num1 = parseFloat(document.getElementById('num1').value);
    let num2 = parseFloat(document.getElementById('num2').value);
    let resultado = num1 - num2;
    document.getElementById('resultadoAritmetico').innerText = 'RESULTADO: ' + resultado;
}

function multiplicar() {
    let num1 = parseFloat(document.getElementById('num1').value);
    let num2 = parseFloat(document.getElementById('num2').value);
    let resultado = num1 * num2;
    document.getElementById('resultadoAritmetico').innerText = 'RESULTADO: ' + resultado;
}

function dividir() {
    let num1 = parseFloat(document.getElementById('num1').value);
    let num2 = parseFloat(document.getElementById('num2').value);

    if(num2 == 0){
        document.getElementById('resultadoAritmetico').innerText = 'Erro! Divisão por Zero não Existe.'
    }
    else{
    let resultado = num1 / num2;
    document.getElementById('resultadoAritmetico').innerText = 'RESULTADO: ' + resultado;
    }
    
}

//--------------------------------------------------------------------------------------------------

//OPERADORES RELACIONAIS

function compararNum(){
    let num1 = parseFloat(document.getElementById('num1').value);
    let num2 = parseFloat(document.getElementById('num2').value);

    if(num1 > num2){
        document.getElementById('resultadoRelacional').innerText = 'Número 1 é maior que Número 2'
    }
    else if(num1 < num2){
        document.getElementById('resultadoRelacional').innerText = 'Número 1 é menor que Número 2'
    }
    else if(num1 == num2){
        document.getElementById('resultadoRelacional').innerText = 'Número 1 é igual Número 2'
    }
}

//------------------------------------------------------------------------------------------------------

//FUNÇÃO DATA E HORA

function dataAtual(){

    let data = new Date();
    let dia = data.getDate();
    let mês = data.getMonth();
    let ano = data.getFullYear();

    document.getElementById('data').innerText = 'Data:' + data;
    document.getElementById('data').innerText = 'Data: ' + dia + '/' + mês + '/' + ano;

    let hora = data.getHours();
    let minutos = data.getMinutes();
    document.getElementById('hora').innerText = "Hora: " + hora + ":" + minutos;
}

//----------------------------------------------------------------------------------------------------


//FUNÇÃO MATEMATICA

function raizQuadrada(){
    numRaiz = parseFloat(document.getElementById('numero').value); 
    let raiz = Math.sqrt(numRaiz);
    let resultado = Math.round(raiz);
    document.getElementById('resultadoRaiz').innerText = "RAIZ DO NÚMERO: " + resultado;
}

//----------------------------------------------------------------------------------------------------

//OPERADORES LÓGICOS

function checkBoxes(){


    let idade = parseFloat(document.getElementById('txtLog').value);

            if (idade % 2 == 0){
                document.getElementById('resultadoLogico1').innerText = "Verdadeiro";
            }
            else{
                document.getElementById('resultadoLogico1').innerText = "Falso";
            }

            if (idade  > 17){
                document.getElementById('resultadoLogico2').innerText = "Verdadeiro";
            }
            else{
                document.getElementById('resultadoLogico2').innerText = "Falso";
            }
        
    
}

//----------------------------------------------------------------------------------------------------

//FUNÇÃO STRING

function Caracteres(){
    let texto = document.getElementById("stringInput").value;
    resultado = texto.length;
    document.getElementById("resultadoString").innerText = "O Número de caracteres é: " + resultado;
}

function inverterString(){
    let texto = document.getElementById("stringInput").value;
    var splitString = texto.split(""); 
    var reverseArray = splitString.reverse(); 
    var joinArray = reverseArray.join(""); 
    document.getElementById("resultadoString").innerText = joinArray;
}
