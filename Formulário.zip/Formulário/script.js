document.getElementById('registration-form').addEventListener('submit', function(event) {
    event.preventDefault(); // Evita o envio real do formulário
    
    let formIsValid = true;
    
    // Validação do nome
    const name = document.getElementById('name');
    const nameError = document.getElementById('name-error');
    if (!name.value.trim()) {
        nameError.textContent = 'Nome é obrigatório.';
        formIsValid = false;
    } else {
        nameError.textContent = '';
    }

    // Validação do email
    const email = document.getElementById('email');
    const emailError = document.getElementById('email-error');
    const emailPattern = /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,6}$/;
    if (!email.value.trim()) {
        emailError.textContent = 'Email é obrigatório.';
        formIsValid = false;
    } else if (!emailPattern.test(email.value)) {
        emailError.textContent = 'Email inválido.';
        formIsValid = false;
    } else {
        emailError.textContent = '';
    }

    // Validação do telefone
    const phone = document.getElementById('phone');
    const phoneError = document.getElementById('phone-error');
    const phonePattern = /^\(\d{2}\)\s\d{4,5}-\d{4}$/;
    if (phone.value && !phonePattern.test(phone.value)) {
        phoneError.textContent = 'Telefone inválido (formato: (xx) xxxx-xxxx).';
        formIsValid = false;
    } else {
        phoneError.textContent = '';
    }

    // Validação da data de nascimento (não permitir datas futuras)
    const birthdate = document.getElementById('birthdate');
    const birthdateError = document.getElementById('birthdate-error');
    const today = new Date().toISOString().split('T')[0];
    if (birthdate.value > today) {
        birthdateError.textContent = 'Data de nascimento não pode ser no futuro.';
        formIsValid = false;
    } else {
        birthdateError.textContent = '';
    }

    // Validação da senha
    const password = document.getElementById('password');
    const passwordError = document.getElementById('password-error');
    if (!password.value.trim()) {
        passwordError.textContent = 'Senha é obrigatória.';
        formIsValid = false;
    } else {
        passwordError.textContent = '';
    }

    // Se o formulário for válido, gerar o JSON
    if (formIsValid) {
        const formData = {
            name: name.value.trim(),
            email: email.value.trim(),
            phone: phone.value.trim(),
            birthdate: birthdate.value,
            password: password.value.trim(),
        };

        const jsonResult = JSON.stringify(formData, null, 2);
        document.getElementById('json-result').textContent = jsonResult;
        document.getElementById('json-output').style.display = 'block';
    }
});

  